#import <UIKit/UIKit.h>

class SpEventGroup;

@interface SpBrUISwitchViewIOS : UISwitch {

}

@property SpEventGroup *events;

@end